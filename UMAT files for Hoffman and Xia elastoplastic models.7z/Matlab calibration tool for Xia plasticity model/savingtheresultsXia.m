function [] = savingtheresultsXia(Data,Dir,Name)

tb{1,:} = ('! Elastic Parameters');
tb{2,:} = (['Exx = ', num2str(Data(1))]);
tb{3,:} = (['Eyy = ', num2str(Data(2))]);
tb{4,:} = (['Gxy = ', num2str(Data(3))]);
tb{5,:} = (['nuxy = ', num2str(Data(4))]);
tb{6,:} = (['nuyx = ', num2str(Data(5))]);

tb{8,:} = (['! Plastic parameters']);



tb{11,:} = (['k0_1 = ', num2str(Data(6))]);
tb{12,:} = (['k1_1 = ', num2str(Data(7))]);
tb{13,:} = (['k2_1 = ', num2str(Data(8))]);

tb{17,:} = (['k0_2 = ', num2str(Data(9))]);
tb{18,:} = (['k1_2 = ', num2str(Data(10))]);
tb{19,:} = (['k2_2 = ', num2str(Data(11))]);


tb{22,:} = (['k0_3 = ', num2str(Data(12))]);
tb{23,:} = (['k1_3 = ', num2str(Data(13))]);
tb{24,:} = (['k2_3 = ', num2str(Data(14))]);

tb{9,:} = (['kpot = ', num2str(Data(15))]);

% dummy
tb{30,:} = (['k0_4 = ', num2str(17.9),'!Fictitious part for compression']);
tb{31,:} = (['k1_4 = ', num2str(0)]);
tb{32,:} = (['k2_4 = ', num2str(0.4)]);

tb{35,:} = (['k0_5 = ', num2str(17.9),'!Fictitious part for compression ']);
tb{36,:} = (['k1_5 = ', num2str(0)]);
tb{37,:} = (['k2_5 = ', num2str(0.4)]);

tb{40,:} = (['k0_6 = ', num2str(Data(12)),'!Same as for tension']);
tb{41,:} = (['k1_6 = ', num2str(Data(13))]);
tb{42,:} = (['k2_6 = ', num2str(Data(14))]);





fid = fopen([Dir,'/',Name,'.txt'],'wt');
fprintf(fid,'%s\n',tb{:});
fclose(fid);