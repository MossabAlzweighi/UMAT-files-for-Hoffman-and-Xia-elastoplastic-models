
% Xia fitting tool for 2-D plane case by
% Mossab Alzweighi (mossab@kth.se, Mossab.Alzweighi@gmail.com) 
% Rami Mansour (ramimans@kth.se)  
% KTH Royal Institute of Technology
% To cite this work please use:
% Alzweighi, Mossab, Rami Mansour, Johan Tryding, and Artem Kulachenko. 2021. “Evaluation of Hoffman and Xia
% Plasticity Models against Bi-Axial Tension Experiments of Planar Fiber Network Materials.”
% International Journal of Solids and Structures.
% https://doi.org/10.1016/J.IJSOLSTR.2021.111358.
% Further reading
% https://doi.org/10.1016/j.actamat.2020.11.003.

%
%%
clc;
clear all;
close all;
set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
%% load experimental data
ExpFile = importdata('ExperimentalData.txt'); % input data with the format:
%strain[%], stress[MPa]:MD,45,CD,etc.

ExpFile(:,1)= ExpFile(:,1)/100; % convert strain from [%] to [-]

Rp = 0.02/100; % define plastic yield strain value at 0.02%

for i=1:3
    %%  read exp data
    stress = ExpFile(:,1+i);
    strain = ExpFile(:,1);
    
    % remove NaNs
    stress = stress(stress<=max(stress)); stress = [stress];
    strain = strain(stress<=max(stress)); strain = [strain];
    % remove duplicates
    [strain,Index_unique] = unique(strain);
    stress=stress(Index_unique);
    % save exp stress-strain data
    strain_exp{i} = strain;
    stress_exp{i} = stress;
    
    % scale exp data: divide strain and stress by max strain and stress respectively
    strain_scaled = strain/max(strain); stress_scaled = stress/max(stress);
    
    % fit fifth-order polynomial passing through (0,0) in the interval for scaled strain = [0,0.5]
    M = strain_scaled(strain_scaled<0.5).^[5:-1:1] ;
    p = M\stress_scaled(strain_scaled<0.5);
    
    % compute initial slope
    p = [p;0];
    pder = polyder(p);
    slope_scaled = polyval(pder,strain_scaled(2));
    
    % compute yield Rp02 based on initial slope
    slope = slope_scaled*max(stress)/max(strain);
    strain_scaled_search = 0:0.00001:0.5;
    stress_search = max(stress)*polyval(p,strain_scaled_search);
    strain_search = strain_scaled_search*max(strain);
    Index = find(strain_search-stress_search/slope<Rp);
    Rp02(i) = stress_search(Index(end));
    strain_Rp02(i) = strain_search(Index(end));
    SigYield(i) = Rp02(i);
    
    % compute elastic moduli (E)
    Elastmod(i) = Rp02(i)/(strain_Rp02(i));
    
    % output equivalent plastic stress-strain exp data
    
    strainpleq = strain-stress/Elastmod(i);
    strainpleq = strainpleq(strain>strain_Rp02(i));
    stresspleq = stress(strain>strain_Rp02(i));
    
    strainpleq = strainpleq(strainpleq>0);
    stresspleq = stresspleq(strainpleq>0);
    
    strainpleq = [0;strainpleq];
    stresspleq = [Rp02(i);stresspleq];
    
    % save equivalent plastic stress-strain exp data
    strainpleq_exp{i} = strainpleq;
    stresspleq_exp{i} = stresspleq;
    
    
    
end

%% compute elastic parameters
% elastic moduli, E [MPa]
Exx     = Elastmod(1);
E45     = Elastmod(2);
Eyy     = Elastmod(3);
% yield stresses
sig0x  = Rp02(1);
sig045 = Rp02(2);
sig0y  = Rp02(3);
% Poisson's ratios, nu [-]
nuxy = 0.293*sqrt(Exx/Eyy);
nuyx = nuxy*(Eyy/Exx);
% shear modulus, G [MPa]
Gxy = cos(deg2rad(45))^2*sin(deg2rad(45))^2/(1/E45-(cos(deg2rad(45))^4/...
    Exx+sin(deg2rad(45))^4/Eyy-2*nuxy/Exx*cos(deg2rad(45))^2*...
    sin(deg2rad(45))^2));

%% compute the yield plane gradient tensor (N)
% 1: MD tension
% 2: CD tension
% 3: positive shear
% 4: MD compression
% 5: CD compression
% 6: negative shear

% =================
% tension in MD
kpot  = 3 % (shape parameter k)
n11_1 = 1/sqrt(1+nuxy^2);
n22_1 = -nuxy/sqrt(1+nuxy^2);
n12_1 = 0;

% tension in CD
n11_2 = -nuyx/sqrt(1+nuyx^2);
n22_2 = 1/sqrt(1+nuyx^2);
n12_2 = 0;

% positive shear

n11_3 = 0;
n22_3 = 0;
n12_3 = 1/sqrt(2);

% compression in MD

n11_4 = -1;
n22_4 =  0;
n12_4 =  0;

% compression in CD

n11_5 = 0;
n22_5 = -1;
n12_5 = 0;


% negative shear 
n11_6 = 0;
n22_6 = 0;
n12_6 = -1/sqrt(2);

Nn = [ n11_1     n22_1   n12_1
       n11_2     n22_2   n12_2
       n11_3     n22_3   n12_3
       n11_4     n22_4   n12_4
       n11_5     n22_5   n12_5
       n11_6     n22_6   n12_6];


%% MD-Tension Plastic parametrs

K1     = stresspleq_exp{1} * n11_1;
k0_1   = K1(1);
K1     = K1 -K1(1);
kappa1 = strainpleq_exp{1} * n11_1;

stresspleq = K1;
strainpleq = kappa1;

Y = log(stresspleq-stresspleq(1));
M = [ones(size(stresspleq)),log(strainpleq)];
powerlawpar = M(2:end,:)\Y(2:end);
c1 = exp(powerlawpar(1));
c2 = 1/(powerlawpar(2));

[fitresult, gof] = createFit(kappa1, K1,c1,c2)
k1_1 = fitresult.a;
k2_1 = fitresult.b;
title('MD')

%% CD-Tension Plastic parametrs
K2     = stresspleq_exp{3} * n22_2;
k0_2   = K2(1);
K2     = K2 -K2(1);
kappa2 = strainpleq_exp{3} * n22_2;

stresspleq = K2;
strainpleq = kappa2;

Y=log(stresspleq-stresspleq(1));
M=[ones(size(stresspleq)),log(strainpleq)];
powerlawpar=M(2:end,:)\Y(2:end);
sig0=stresspleq(1);
c1=exp(powerlawpar(1));
c2=1/(powerlawpar(2));

[fitresult, gof]= createFit(kappa2, K2,c1,c2)

k1_2 = fitresult.a;
k2_2 = fitresult.b;
title('CD')
%% 45D positive shear Plastic parametrs

C1 = (n11_1 * sig0x)/(0.5*sig045);
C2 = (n22_2 * sig0y)/(0.5*sig045);
twokpot = 2*kpot;

cons1  = 1- ( (n11_1+ n22_1)/C1  )^(twokpot) - ( (n11_2+n22_2)/C2 )^...
         (twokpot);
K3     = stresspleq_exp{2} * n12_3 * cons1^(-1/twokpot);
k0_3   = K3(1);
K3     = K3 -K3(1);
kappa3 = ( 1/n12_3 )*cons1 ^(1/twokpot) *strainpleq_exp{2} ;


stresspleq = K3;
strainpleq = kappa3;
Y = log(stresspleq-stresspleq(1));
M = [ones(size(stresspleq)),log(strainpleq)];
powerlawpar = M(2:end,:)\Y(2:end);
sig0 = stresspleq(1);
c1 = exp(powerlawpar(1));
c2 = 1/(powerlawpar(2));

[fitresult, gof] = createFit(kappa3, K3,c1,c2)
k1_3 = fitresult.a;
k2_3 = fitresult.b;

title('45D')

%% save the results to input card
    
Data = [Exx Eyy Gxy nuxy nuyx...
    k0_1 k1_1 k2_1...
    k0_2 k1_2 k2_2...
    k0_3 k1_3 k2_3 ...
    kpot];

savingtheresultsXia(Data,pwd,'XiaCard')

% Note: the fitting results can be enhancd by optimizing the above input
% data (XiaCard) using Ansys



