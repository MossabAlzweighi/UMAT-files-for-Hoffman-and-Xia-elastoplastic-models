- Matlab calibration tool for Xia plasticity model for 2D plane stress case.

For more information and citation, please refer to:

Alzweighi, Mossab, Rami Mansour, Johan Tryding, and Artem Kulachenko. 2021. “Evaluation of Hoffman and Xia
Plasticity Models against Bi-Axial Tension Experiments of Planar Fiber Network Materials.”
International Journal of Solids and Structures.
https://doi.org/10.1016/J.IJSOLSTR.2021.111358.
Further reading
https://doi.org/10.1016/j.actamat.2020.11.003.

- To run the calibration tool run "XiaFittingTool.m"
- File "ExperimentalData.txt" is the experimental results of the uniaxial test of the material in three directions 
(for orthotropic materials). 
- The format of the experimental data should be as
strain [%], stress [Mpa] first principal direction, stress [Mpa] with 45 angle between the first and second principal direction,stress [Mpa] second principal direction  
- The tool will return the elastic and plastic material parameters for the Xia model
- The "XiaCard.txt" contains the material parameters as

Elastic parameters

Ex: elastic modulus for the first principal direction
Ey: elastic modulus for the second principal direction
Gxy: shear modulus
n_uxy: Poisson's ratio (in the tool the Poisson's ratio is calculated as 0.293*sqrt(Ex/Ey) which is applicable for fibrous materials)

Plastic parameters

The plastic hardening parameters for the tensile sub-surfaces.