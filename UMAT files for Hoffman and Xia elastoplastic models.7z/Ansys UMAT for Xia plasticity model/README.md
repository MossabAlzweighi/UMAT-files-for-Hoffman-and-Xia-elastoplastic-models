Xia plasticity model sub routine for 2-D plane stress case with anisotropic proprties and assymteric tension-compression response 
for 2-D plane stress case.
Mossab Alzweighi (mossab@kth.se)
KTH Royal Institute of Technology

For citing this work please use: 

Alzweighi, Mossab, Rami Mansour, Johan Tryding, and Artem Kulachenko. 2021. “Evaluation of Hoffman and Xia
Plasticity Models against Bi-Axial Tension Experiments of Planar Fiber Network Materials.”
International Journal of Solids and Structures.
https://doi.org/10.1016/J.IJSOLSTR.2021.111358.
Further reading
https://doi.org/10.1016/j.actamat.2020.11.003.
 

For linking UMAT in Ansys please refer to the file "Instruction for liniking UMAT to Ansys.pdf" 